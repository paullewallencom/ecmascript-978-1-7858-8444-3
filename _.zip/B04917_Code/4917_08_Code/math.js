import * as logarithm from "math_modules/logarithm.js";
import * as trigonometry from "math_modules/trigonometry.js";

export default {
	logarithm: logarithm,
	trigonometry: trigonometry
};